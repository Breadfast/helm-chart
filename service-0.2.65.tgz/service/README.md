# service

![Version: 0.2.65](https://img.shields.io/badge/Version-0.2.65-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

A Helm chart for Kubernetes.

When gateway.enabled is true, the chart creates **Gateway API** resources separately from Ingress:

- **HTTPRoute** (gateway.networking.k8s.io/v1) – routes traffic from a Gateway to this service (hostnames and paths from gateway.hosts).
- **HealthCheckPolicy** (networking.gke.io/v1) – GKE health check policy for the service when gateway.healthCheck.enabled is true (TCP or HTTP).
- **GCPBackendPolicy** (networking.gke.io/v1) – binds a Cloud Armor security policy to the Gateway backend Service when gateway.backendPolicy.enabled is true.

Ingress resources are unchanged; you can use Ingress only, Gateway only, or both.

When networkPolicy.enabled and networkPolicy.internetOnly.enabled are true, the chart creates an egress-only
NetworkPolicy that allows DNS and public internet traffic while excluding common private/internal CIDRs.
NetworkPolicy works by IP/CIDR, so add the actual cluster Pod, Service, and internal VPC CIDRs to
networkPolicy.internetOnly.ipBlock.except when they are outside the defaults.

**Homepage:** <https://github.com/Breadfast/helm-chart>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| DevOps-team | <devops@breadfast.com> |  |

## Source Code

* <https://github.com/Breadfast/helm-chart>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| argoPreSyncValidator | object | `{"annotations":{},"backoffLimit":1,"command":["php","-l","/vault/secrets/wp-config.php"],"enabled":false,"ttlSecondsAfterFinished":60}` | If true, create ArgoCD PreSync job to validate environment variables injected from Vault |
| argorollouts.dynamicStableScale | bool | `true` |  |
| argorollouts.enabled | bool | `false` |  |
| argorollouts.steps[0].setWeight | int | `20` |  |
| argorollouts.steps[1].pause.duration | string | `"1m"` |  |
| argorollouts.steps[2].setWeight | int | `60` |  |
| argorollouts.steps[3].pause | object | `{}` |  |
| autoscaling.enabled | bool | `false` |  |
| containerEnv | map | `[]` | Environment variable map |
| cronJob | bool | `{"create":false}` | If true, Creates CronJob resource |
| datadog | bool | `{"enabled":false}` | If true, Add datadog labels to pods and deployments |
| deploymentLabels | object | `{}` |  |
| destinationRule.enabled | bool | `false` |  |
| destinationRule.trafficPolicy | object | `{}` |  |
| entrypointOverride | bool | `{"enabled":false}` | If true, Override to the Entrypoint |
| extraService.enabled | bool | `false` |  |
| extraService.port | int | `9113` |  |
| extraService.portName | string | `"extraport"` |  |
| extraService.targetPort | int | `9113` |  |
| extraService.type | string | `"ClusterIP"` |  |
| fullnameOverride | string | `""` |  |
| gateway | bool | `{"annotations":{},"backendPolicy":{"enabled":false,"securityPolicy":""},"enabled":false,"gatewayName":"","gatewayNamespace":"gateway-infra","healthCheck":{"checkIntervalSec":30,"enabled":false,"healthyThreshold":1,"port":80,"timeoutSec":10,"type":"TCP","unhealthyThreshold":5},"hosts":[]}` | If true, creates Gateway API resources (HTTPRoute + optional HealthCheckPolicy) separately from Ingress. Ingress can remain enabled for traditional Ingress; gateway resources are independent. |
| gateway.annotations | object | `{}` | Additional annotations for HTTPRoute |
| gateway.backendPolicy | object | `{"enabled":false,"securityPolicy":""}` | GKE GCPBackendPolicy (networking.gke.io/v1). When enabled, binds a Cloud Armor    security policy to the backend Service used by the Gateway (e.g. for edge IP    blocking / rate limiting). The referenced securityPolicy must already exist in    the same GCP project before this resource is applied. |
| gateway.backendPolicy.securityPolicy | string | `""` | Name of an existing Cloud Armor security policy (required when enabled) |
| gateway.gatewayName | string | `""` | Gateway name for HTTPRoute parentRefs (e.g. breadfast-gateway) |
| gateway.gatewayNamespace | string | `"gateway-infra"` | Gateway namespace for parentRefs (e.g. gateway-infra) |
| gateway.healthCheck | object | `{"checkIntervalSec":30,"enabled":false,"healthyThreshold":1,"port":80,"timeoutSec":10,"type":"TCP","unhealthyThreshold":5}` | GKE HealthCheckPolicy (networking.gke.io/v1). When enabled, creates a HealthCheckPolicy targeting the service. |
| gateway.healthCheck.checkIntervalSec | int | `30` | Check interval in seconds |
| gateway.healthCheck.healthyThreshold | int | `1` | Healthy threshold count |
| gateway.healthCheck.port | int | `80` | Port for health check (e.g. app port 3000; can differ from service port) |
| gateway.healthCheck.timeoutSec | int | `10` | Timeout in seconds |
| gateway.healthCheck.type | string | `"TCP"` | Health check type: TCP or HTTP |
| gateway.healthCheck.unhealthyThreshold | int | `5` | Unhealthy threshold count |
| gateway.hosts | list | `[]` | Hosts and paths for HTTPRoute (same shape as ingress.hosts) |
| gcpVolumeMounts | bool | `{"enabled":false}` | If true, add annotation o enable GCP Volume Mounts (GCSFuse) |
| goreplay.args[0] | string | `"-input-raw"` |  |
| goreplay.args[1] | string | `"any:80"` |  |
| goreplay.args[2] | string | `"--output-file"` |  |
| goreplay.args[3] | string | `"/traffic/requests-%Y-%m-%d-%H.log"` |  |
| goreplay.args[4] | string | `"-verbose"` |  |
| goreplay.args[5] | string | `"2"` |  |
| goreplay.args[6] | string | `"--output-file-append"` |  |
| goreplay.enabled | bool | `false` |  |
| goreplay.gcpbucketName | string | `"goreplay-non-prod"` |  |
| goreplay.image | string | `"us-central1-docker.pkg.dev/prj-n-floating-623c/apps/goreplay:latest"` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"repo/image"` |  |
| image.tag | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| ingress | bool | `{"enabled":false}` | If true, Creats Ingress DNS name to expose the service publicly |
| livenessProbe | object | `{}` |  |
| multiIngress | bool | `{"enabled":false}` | If true, Creats Multible Ingresses DNS name to expose the service publicly |
| nameOverride | string | `""` |  |
| networkPolicy | object | `{"annotations":{},"egress":[],"enabled":false,"ingress":[],"internetOnly":{"allowDNS":true,"dns":{"namespaceSelector":{"matchLabels":{"kubernetes.io/metadata.name":"kube-system"}},"podSelector":{"matchLabels":{"k8s-app":"kube-dns"}},"ports":[{"port":53,"protocol":"UDP"},{"port":53,"protocol":"TCP"}]},"enabled":false,"ipBlock":{"cidr":"0.0.0.0/0","except":["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10","127.0.0.0/8","169.254.0.0/16","224.0.0.0/4","240.0.0.0/4"]}},"podSelector":{},"policyTypes":["Egress"]}` | NetworkPolicy configuration for controlling pod network traffic |
| networkPolicy.annotations | object | `{}` | Additional annotations for the NetworkPolicy |
| networkPolicy.egress | list | `[]` | Raw additional egress rules appended after the internetOnly rules |
| networkPolicy.enabled | bool | `false` | If true, creates a NetworkPolicy for the main service workload pods |
| networkPolicy.ingress | list | `[]` | Raw ingress rules. Only used when policyTypes includes Ingress or when rules are provided |
| networkPolicy.internetOnly | object | `{"allowDNS":true,"dns":{"namespaceSelector":{"matchLabels":{"kubernetes.io/metadata.name":"kube-system"}},"podSelector":{"matchLabels":{"k8s-app":"kube-dns"}},"ports":[{"port":53,"protocol":"UDP"},{"port":53,"protocol":"TCP"}]},"enabled":false,"ipBlock":{"cidr":"0.0.0.0/0","except":["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10","127.0.0.0/8","169.254.0.0/16","224.0.0.0/4","240.0.0.0/4"]}}` | Internet-only egress profile. Allows DNS and public internet while excluding private/internal CIDRs |
| networkPolicy.internetOnly.allowDNS | bool | `true` | If true, allows DNS egress to the configured DNS pods |
| networkPolicy.internetOnly.dns | object | `{"namespaceSelector":{"matchLabels":{"kubernetes.io/metadata.name":"kube-system"}},"podSelector":{"matchLabels":{"k8s-app":"kube-dns"}},"ports":[{"port":53,"protocol":"UDP"},{"port":53,"protocol":"TCP"}]}` | DNS egress target used by the internetOnly profile |
| networkPolicy.internetOnly.dns.namespaceSelector | object | `{"matchLabels":{"kubernetes.io/metadata.name":"kube-system"}}` | Namespace selector for DNS pods |
| networkPolicy.internetOnly.dns.podSelector | object | `{"matchLabels":{"k8s-app":"kube-dns"}}` | Pod selector for DNS pods |
| networkPolicy.internetOnly.dns.ports | list | `[{"port":53,"protocol":"UDP"},{"port":53,"protocol":"TCP"}]` | DNS ports allowed by the internetOnly profile |
| networkPolicy.internetOnly.enabled | bool | `false` | If true, adds DNS and public internet egress rules |
| networkPolicy.internetOnly.ipBlock | object | `{"cidr":"0.0.0.0/0","except":["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10","127.0.0.0/8","169.254.0.0/16","224.0.0.0/4","240.0.0.0/4"]}` | Public egress ipBlock used by the internetOnly profile |
| networkPolicy.internetOnly.ipBlock.cidr | string | `"0.0.0.0/0"` | Public internet CIDR allowed by the internetOnly profile |
| networkPolicy.internetOnly.ipBlock.except | list | `["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10","127.0.0.0/8","169.254.0.0/16","224.0.0.0/4","240.0.0.0/4"]` | CIDRs excluded from public internet egress. Add cluster Pod, Service, and internal VPC CIDRs here if they are outside these defaults |
| networkPolicy.podSelector | object | `{}` | Custom NetworkPolicy podSelector. When empty, selects the main Deployment/Rollout pods using the chart selector labels |
| networkPolicy.policyTypes | list | `["Egress"]` | NetworkPolicy policy types. Defaults to Egress only so ingress traffic remains unchanged |
| nodeSelectorLabels | object | `{}` | Provide node groups selector |
| nodeTolerations | list | `[]` | Node Tolerations. Tolerations allow the scheduler to schedule pods with matching taints |
| pdb.enabled | bool | `false` |  |
| pdb.minAvailable | string | `"60%"` |  |
| podAffinity | object | `{}` | Pod affinity rule. Default affinity rule is set to make sure pods are not deployed on the same node |
| podAnnotations | object | `{}` |  |
| podAntiAffinity | object | `{}` |  |
| podLabels | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| readinessProbe | object | `{}` |  |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| rollingStrategy | string | `"RollingUpdate"` | Specify deployment rolling strategy: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy |
| securityContext | object | `{}` |  |
| service.annotations | object | `{}` | Additional annotations for the Kubernetes Service |
| service.name | string | `"http"` | Service port name when single port service |
| service.port | int | `80` | Kubernetes service port when single port service |
| service.ports | list | `[]` | Used when the service container requires multiple ports. The port parameter will be ignored if this is set.    Example:       - name: http         port: 8069         targetPort: 8069       - name: websocket         port: 8072         targetPort: 8072       - name: xmlrpc         port: 8071         targetPort: 8071 |
| service.targetPort | int | `80` |  |
| service.type | string | `"ClusterIP"` | Service type, can be either `ClusterIP`, `NodePort`, `LoadBalancer` or `ExternalName` |
| serviceAccount.annotations | object | `{}` | If not set and create is true, a name is generated using the fullname template |
| serviceAccount.create | bool | `false` | If true, creates service account |
| serviceAccount.name | string | `""` |  |
| startupProbe | object | `{}` |  |
| vaultAgent | bool | `{"enabled":false}` | If true, It will inject Vault Agent to get secrets from Vault |
| virtualService.enabled | bool | `false` |  |
| virtualService.hosts | list | `[]` |  |
| virtualService.http | object | `{}` |  |
| volumeMounts | list | `[]` | List of volumes to attach |
| volumes | list | `[]` | To add GCP Bucket as volume, use the following format - name: volume-name   csi:     driver: gcsfuse.csi.storage.gke.io     volumeAttributes:       bucketName: gcp-bucket-name       mountOptions: "implicit-dirs"       gcsfuseLoggingSeverity: warning |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
